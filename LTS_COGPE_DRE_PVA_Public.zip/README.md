# LTS COGPE DRE PVA

Este é o sistema de acompanhamento LTS publicado via GitHub Pages / Netlify.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie os arquivos desta pasta (index.html e README.md).
3. Vá em Settings -> Pages -> Ative a opção GitHub Pages.
4. O link será gerado automaticamente.

## Como publicar no Netlify

1. Crie uma conta no [Netlify](https://www.netlify.com/).
2. Arraste e solte esta pasta na área de upload.
3. O link será gerado automaticamente.
